package com.example.myapplication;

import java.util.ArrayList;

public class Students {
    private  String name;
    private String phone;
    private String email;
    private String roll;
    private String no;
    private String registration;
    private String dept;
    private String year;
    private String admission;
    private String gender;

    private static ArrayList<Students> studentlist;

    static {
        studentlist = new ArrayList<Students>();
    }

    public Students(String name, String phone, String email, String roll, String no, String registration, String dept, String year, String admission, String gender) {
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.roll = roll;
        this.no = no;
        this.registration = registration;
        this.dept = dept;
        this.year = year;
        this.admission = admission;
        this.gender = gender;

    }

    public Students(String name, String phone, String dept, String roll, String registration, String no, String year, String admission, String email) {
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getRoll() {
        return roll;
    }

    public String getNo() {
        return no;
    }

    public String getRegistration() {
        return registration;
    }

    public String getDept() {
        return dept;
    }

    public String getYear() {
        return year;
    }

    public String getAdmission() {
        return admission;
    }

    public String getGender() {
        return gender;
    }


}
