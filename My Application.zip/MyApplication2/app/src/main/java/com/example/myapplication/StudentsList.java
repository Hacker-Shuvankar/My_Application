package com.example.myapplication;

import android.app.Activity;

public class StudentsList extends Activity {
}
