package com.example.myapplication;

import android.Manifest;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.io.InputStream;

public class ADDSTUDENT extends AppCompatActivity {
    EditText nameET,phoneET,deptET,rollET,RegistrationET,noET,yearET,AdmissionET,emailET;
    RadioGroup genderRG;
    String gender;
    ImageView img;
    Button browse,upload;
    Uri filepath;
    Bitmap bitmap;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addstudent);
        nameET=findViewById(R.id.nameET);
        phoneET=findViewById(R.id.phoneET);
        deptET=findViewById(R.id.deptET);
        rollET=findViewById(R.id.rollET);
        noET=findViewById(R.id.noET);
        RegistrationET=findViewById(R.id.RegistrationET);
        yearET=findViewById(R.id.yearET);
        AdmissionET=findViewById(R.id.AdmissionET);
        emailET=findViewById(R.id.emailET);
        genderRG=findViewById(R.id.genderRG);

        genderRG.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton genderRB = findViewById((checkedId));
                String gender = genderRB.getText().toString();
            }
        });

        img=(ImageView) findViewById(R.id.imageView);
        upload=(Button) findViewById(R.id.upload);
        browse=(Button) findViewById(R.id.browse);

                browse.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        Dexter.withActivity(ADDSTUDENT.this)
                                .withPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                                .withListener(new PermissionListener() {
                                    @Override
                                    public void onPermissionGranted(PermissionGrantedResponse response) {
                                        Intent intent=new Intent(Intent.ACTION_PICK);
                                        intent.setType("image/*");
                                        startActivityForResult(Intent.createChooser(intent,"Please select Image"),1);
                                    }

                                    @Override
                                    public void onPermissionDenied(PermissionDeniedResponse response) {

                                    }

                                    @Override
                                    public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                                        token.continuePermissionRequest();
                                    }
                                }).check();
                    }
                });

                upload.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        uploadtofirebase();
                    }
                });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable @androidx.annotation.Nullable Intent data) {
        if(requestCode==1 && resultCode==RESULT_OK){
            filepath=data.getData();
            try {
                InputStream inputStream=getContentResolver().openInputStream(filepath);
                bitmap= BitmapFactory.decodeStream(inputStream);
                img.setImageBitmap(bitmap);
            }catch (Exception ex){

            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void  image(View view ){
        Toast.makeText(this,"Upload image", Toast.LENGTH_SHORT).show();
    }

    public void submitStudent(View view) {
        String name = nameET.getText().toString();
        String phone = phoneET.getText().toString();
        String dept = deptET.getText().toString();
        String roll = rollET.getText().toString();
        String registration = RegistrationET.getText().toString();
        String no = noET.getText().toString();
        String year = yearET.getText().toString();
        String admission = AdmissionET.getText().toString();
        String email = emailET.getText().toString();



        Students student = new Students(name,phone,dept,roll,registration,no,year,admission,email);
        if ((name.matches("") || phone.matches("") || dept.matches("") || roll.matches("") || registration.matches("") || no.matches("") || year.matches("") || admission.matches("") || email.matches("")))
        {
            Toast.makeText(this, "Plase Fill the Empty Block", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(this, "Student Add Successfully", Toast.LENGTH_SHORT).show();
        }
    }
}